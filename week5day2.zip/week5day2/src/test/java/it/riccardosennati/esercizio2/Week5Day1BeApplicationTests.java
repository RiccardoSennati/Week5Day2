package it.riccardosennati.es2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5Day1BeApplicationTests {

	@Test
	void contextLoads() {
	}

}
