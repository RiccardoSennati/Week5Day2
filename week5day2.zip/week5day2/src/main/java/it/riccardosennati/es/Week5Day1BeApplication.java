package it.riccardosennati.es;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5Day1BeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week5Day1BeApplication.class, args);
		System.out.println("Ciao Mondo!");
	}

}
